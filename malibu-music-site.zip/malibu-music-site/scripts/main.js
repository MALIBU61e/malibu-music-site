const musicList = document.getElementById('musicList');
const searchInput = document.getElementById('searchInput');

// Temporary sample songs
const songs = [
  {
    title: "Dreamer",
    artist: "Malibu",
    album: "Night Vibes",
    genre: "Hip-Hop",
    size: "5.2 MB",
    year: "2025-07-01",
    artwork: "artwork/dreamer.jpg",
    file: "music/dreamer.mp3"
  },
  {
    title: "Moonlight",
    artist: "Malibu",
    album: "Chill Trap",
    genre: "Trap",
    size: "4.8 MB",
    year: "2025-06-20",
    artwork: "",
    file: "music/moonlight.mp3"
  }
];

function loadSongs(data) {
  musicList.innerHTML = "";
  data.forEach(song => {
    const card = document.createElement("div");
    card.className = "song-card";
    card.innerHTML = `
      <img src="${song.artwork || 'assets/default-art.jpg'}" alt="${song.title}">
      <div class="song-info">
        <h3>${song.title}</h3>
        <p>Artist: ${song.artist}</p>
        <p>Album: ${song.album}</p>
        <p>Genre: ${song.genre}</p>
        <p>Size: ${song.size}</p>
        <p>Released: ${song.year}</p>
      </div>
      <div class="song-actions">
        <button onclick="playPreview('${song.file}')">▶️ Play</button>
        <a href="${song.file}" download><button>📥 Download</button></a>
        <button class="like-btn" onclick="likeSong(this)">❤️</button>
      </div>
    `;
    musicList.appendChild(card);
  });
}

function playPreview(file) {
  const audio = new Audio(file);
  audio.play();
}

function likeSong(btn) {
  btn.style.color = 'red';
  btn.disabled = true;
}

function toggleSearch() {
  const input = document.getElementById('searchInput');
  input.style.display = input.style.display === 'none' ? 'block' : 'none';
  if (input.style.display === 'block') input.focus();
}

searchInput.addEventListener("input", () => {
  const keyword = searchInput.value.toLowerCase();
  const filtered = songs.filter(song =>
    song.title.toLowerCase().includes(keyword) ||
    song.artist.toLowerCase().includes(keyword) ||
    song.album.toLowerCase().includes(keyword) ||
    song.genre.toLowerCase().includes(keyword) ||
    song.year.includes(keyword)
  );
  loadSongs(filtered);
});

loadSongs(songs);
